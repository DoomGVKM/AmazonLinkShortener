﻿using System;
using System.Windows.Forms;

namespace Link_Shortener
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private bool Validation()
        {
            bool ReturnValue = false;
            if (ShortBox.Text.StartsWith("https://www.amazon.com") || ShortBox.Text.StartsWith("www.amazon.com") || ShortBox.Text.StartsWith("amazon.com"))
                ReturnValue = true;
            return ReturnValue;
        }
        private void Shorten()
        {
            try
            {
                string LinkID = ShortBox.Text.TextAfter("dp/").Remove(10);
                ShortBox.Text = LinkID.Insert(0, "https://www.amazon.com/dp/");
            }
            catch (Exception)
            {
                ShortBox.Text = "Link Already Shortend";
            }
        }
        private void ShortButton_Click(object sender, EventArgs e)
        {
            if (Validation() == true)
                Shorten();
        }
    }
    public static class Extension
    {
        public static string TextAfter(this string value, string search) => value.Substring(value.IndexOf(search) + search.Length);
    }
}
