﻿namespace Link_Shortener
{
    partial class MainWindow
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.ShortBox = new System.Windows.Forms.TextBox();
            this.ShortDrop = new System.Windows.Forms.ComboBox();
            this.ShortButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            this.ShortBox.Location = new System.Drawing.Point(21, 15);
            this.ShortBox.Name = "ShortBox";
            this.ShortBox.Size = new System.Drawing.Size(397, 20);
            this.ShortBox.TabIndex = 0;
            this.ShortDrop.FormattingEnabled = true;
            this.ShortDrop.Items.AddRange(new object[] {"Type: Amazon"});
            this.ShortDrop.Location = new System.Drawing.Point(21, 41);
            this.ShortDrop.Name = "ShortDrop";
            this.ShortDrop.Size = new System.Drawing.Size(318, 21);
            this.ShortDrop.TabIndex = 1;
            this.ShortDrop.Text = "Type: Amazon";
            this.ShortButton.BackColor = System.Drawing.SystemColors.Window;
            this.ShortButton.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.ShortButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ShortButton.Location = new System.Drawing.Point(345, 41);
            this.ShortButton.Name = "ShortButton";
            this.ShortButton.Size = new System.Drawing.Size(73, 21);
            this.ShortButton.TabIndex = 2;
            this.ShortButton.Text = "Shorten";
            this.ShortButton.UseVisualStyleBackColor = false;
            this.ShortButton.Click += new System.EventHandler(this.ShortButton_Click);
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 81);
            this.Controls.Add(this.ShortButton);
            this.Controls.Add(this.ShortDrop);
            this.Controls.Add(this.ShortBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MinimizeBox = false;
            this.Name = "MainWindow";
            this.Text = "Amazon Link Shortener";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox ShortBox;
        private System.Windows.Forms.ComboBox ShortDrop;
        private System.Windows.Forms.Button ShortButton;
    }
}

