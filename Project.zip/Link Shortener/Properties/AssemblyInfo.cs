﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Amazon Link Shortener")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("DoomGVKM (https://github.com/DoomGVKM)")]
[assembly: AssemblyProduct("Amazon Link Shortener")]
[assembly: AssemblyCopyright("Copyright © DoomGVKM 2020, All rights reserved")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("0dd68ce1-b37f-486a-8788-db29990cd4a0")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
