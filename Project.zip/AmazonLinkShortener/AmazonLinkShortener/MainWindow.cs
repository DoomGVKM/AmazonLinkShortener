﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace AmazonLinkShortener
{
    public class MainWindow : Form
    {
        public MainWindow() => InitializeComponent();
        private bool Validation()
        {
            bool ReturnValue = false;
            if (ShortBox.Text.StartsWith("https://www.amazon.com") || ShortBox.Text.StartsWith("www.amazon.com") || ShortBox.Text.StartsWith("amazon.com"))
                ReturnValue = true;
            return ReturnValue;
        }
        private void Shorten()
        {
            try
            {
                string LinkID = ShortBox.Text.TextAfter("dp/").Remove(10);
                ShortBox.Text = LinkID.Insert(0, "https://www.amazon.com/dp/");
            }
            catch (Exception)
            {
                ShortBox.Text = "Link Already Shortend";
            }
        }
        private void ShortButton_Click(object sender, EventArgs e)
        {
            if (Validation() == true)
                Shorten();
        }
        private void MainWindow_FormClosing(object sender, EventArgs e) => Environment.Exit(1);
        private readonly IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            Dispose(disposing);
        }
        private void InitializeComponent()
        {
            ShortBox = new TextBox();
            ShortDrop = new ComboBox();
            ShortButton = new Button();
            SuspendLayout();
            FormClosing += new FormClosingEventHandler(MainWindow_FormClosing);
            ShortBox.Location = new Point(21, 15);
            ShortBox.Name = "ShortBox";
            ShortBox.Size = new Size(397, 20);
            ShortBox.TabIndex = 0;
            ShortDrop.FormattingEnabled = true;
            ShortDrop.Items.AddRange(new object[] { "Type: Amazon" });
            ShortDrop.Location = new Point(21, 41);
            ShortDrop.Name = "ShortDrop";
            ShortDrop.Size = new Size(318, 21);
            ShortDrop.TabIndex = 1;
            ShortDrop.Text = "Type: Amazon";
            ShortButton.BackColor = SystemColors.Window;
            ShortButton.FlatAppearance.BorderColor =Color.Gray;
            ShortButton.FlatStyle = FlatStyle.Flat;
            ShortButton.Location = new Point(345, 41);
            ShortButton.Name = "ShortButton";
            ShortButton.Size = new Size(73, 21);
            ShortButton.TabIndex = 2;
            ShortButton.Text = "Shorten";
            ShortButton.UseVisualStyleBackColor = false;
            ShortButton.Click += new EventHandler(this.ShortButton_Click);
            AutoScaleDimensions = new SizeF(6F, 13F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(436, 81);
            Controls.Add(ShortButton);
            Controls.Add(ShortDrop);
            Controls.Add(ShortBox);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MinimizeBox = false;
            Name = "MainWindow";
            Text = "Amazon Link Shortener";
            ResumeLayout(false);
            PerformLayout();
        }
        private TextBox ShortBox;
        private ComboBox ShortDrop;
        private Button ShortButton;
    }
}
