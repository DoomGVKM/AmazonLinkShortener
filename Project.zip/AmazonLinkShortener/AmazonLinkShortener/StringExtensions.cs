﻿namespace AmazonLinkShortener
{
    public static class StringExtensions
    {
        public static string TextAfter(this string value, string search) => value.Substring(value.IndexOf(search) + search.Length);
    }
}
